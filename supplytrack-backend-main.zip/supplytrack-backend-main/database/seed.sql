-- Default password for every seeded account is: password123
SET @password_hash = '$2b$10$1lb27d.iuKOT17Sc3pRh0eGdk/v26Myb.4fTkdHM1U6dsh7rd3MDO';

INSERT INTO users (id, full_name, email, phone, password, role, status) VALUES
(1, 'Admin User', 'admin@supplytrack.test', '0700000001', @password_hash, 'admin', 'active'),
(2, 'Customer One', 'customer@supplytrack.test', '0700000002', @password_hash, 'customer', 'active'),
(3, 'Amina Customer', 'amina@supplytrack.test', '0700000003', @password_hash, 'customer', 'active'),
(4, 'Peter Customer', 'peter@supplytrack.test', '0700000004', @password_hash, 'customer', 'active'),
(5, 'Kampala Supplier', 'supplier@supplytrack.test', '0700000005', @password_hash, 'supplier', 'active'),
(6, 'Green Farm Supplier', 'greenfarm@supplytrack.test', '0700000006', @password_hash, 'supplier', 'active'),
(7, 'Campus Hardware Supplier', 'hardware@supplytrack.test', '0700000007', @password_hash, 'supplier', 'active'),
(8, 'Station Officer One', 'station@supplytrack.test', '0700000008', @password_hash, 'station_officer', 'active'),
(9, 'Station Officer Two', 'station2@supplytrack.test', '0700000009', @password_hash, 'station_officer', 'active');

INSERT INTO supplier_profiles (id, user_id, business_name, business_description, district, address, phone, status) VALUES
(1, 5, 'Kampala Office Supplies', 'Stationery, electronics, and student supplies.', 'Kampala', 'Nakasero Market Road', '0700000005', 'active'),
(2, 6, 'Green Farm Inputs', 'Quality farm inputs and groceries.', 'Wakiso', 'Gayaza Road', '0700000006', 'active'),
(3, 7, 'Campus Hardware Depot', 'Hardware and household items for homes and hostels.', 'Mukono', 'Seeta Trading Center', '0700000007', 'active');

INSERT INTO pickup_stations (id, station_name, district, location_details, officer_id, phone, status) VALUES
(1, 'Makerere Main Gate Station', 'Kampala', 'Near the main gate security office', 8, '0711000001', 'active'),
(2, 'Nakawa Pickup Point', 'Kampala', 'Opposite the student center', 9, '0711000002', 'active'),
(3, 'Mukono Central Station', 'Mukono', 'Next to taxi park entrance', 8, '0711000003', 'active');

INSERT INTO item_categories (id, name, description, status) VALUES
(1, 'Electronics', 'Phones, chargers, adapters, and small electronics', 'active'),
(2, 'Stationery', 'Books, paper, pens, and student supplies', 'active'),
(3, 'Groceries', 'Food and daily grocery items', 'active'),
(4, 'Hardware', 'Tools, locks, bulbs, and repair supplies', 'active'),
(5, 'Household Items', 'Home and hostel essentials', 'active'),
(6, 'Farm Inputs', 'Seeds, feeds, fertilizers, and farm tools', 'active');

INSERT INTO items (id, supplier_id, category_id, item_name, description, price, stock_quantity, unit, image, status) VALUES
(1, 1, 1, 'USB-C Phone Charger', 'Fast charging adapter for Android phones.', 35000, 25, 'piece', NULL, 'active'),
(2, 1, 1, 'Power Bank 10000mAh', 'Portable backup power for phones and tablets.', 85000, 12, 'piece', NULL, 'active'),
(3, 1, 2, 'A4 Exercise Books Pack', 'Pack of six ruled exercise books.', 18000, 60, 'pack', NULL, 'active'),
(4, 1, 2, 'Blue Ballpoint Pens', 'Box of 50 smooth-writing pens.', 22000, 30, 'box', NULL, 'active'),
(5, 2, 3, 'Premium Rice 5kg', 'Long grain rice for household use.', 24000, 40, 'bag', NULL, 'active'),
(6, 2, 3, 'Cooking Oil 3L', 'Vegetable cooking oil.', 27000, 35, 'bottle', NULL, 'active'),
(7, 2, 6, 'Maize Seeds 2kg', 'High-yield maize seeds for planting.', 16000, 45, 'bag', NULL, 'active'),
(8, 2, 6, 'Organic Fertilizer 10kg', 'Soil-friendly organic fertilizer.', 30000, 20, 'bag', NULL, 'active'),
(9, 3, 4, 'Padlock Medium', 'Durable padlock with three keys.', 12000, 50, 'piece', NULL, 'active'),
(10, 3, 4, 'LED Bulb 12W', 'Energy-saving bulb for homes and hostels.', 9000, 80, 'piece', NULL, 'active'),
(11, 3, 5, 'Plastic Storage Box', 'Stackable household storage container.', 28000, 18, 'piece', NULL, 'active'),
(12, 3, 5, 'Cotton Bedsheet', 'Comfortable bedsheet for single bed.', 32000, 22, 'piece', NULL, 'active');

INSERT INTO carts (id, customer_id) VALUES
(1, 2),
(2, 3);

INSERT INTO cart_items (cart_id, item_id, quantity) VALUES
(1, 1, 1),
(1, 3, 2),
(2, 5, 1);

INSERT INTO orders (id, customer_id, supplier_id, pickup_station_id, order_number, total_amount, status, customer_notes) VALUES
(1, 2, 1, 1, 'ST-SEED-001', 53000, 'Ready for Pickup', 'Please call me when ready.'),
(2, 3, 2, 2, 'ST-SEED-002', 54000, 'In Transit to Pickup Station', NULL),
(3, 4, 3, 3, 'ST-SEED-003', 41000, 'Completed', 'Pickup by customer ID.');

INSERT INTO order_items (order_id, item_id, quantity, unit_price, subtotal) VALUES
(1, 1, 1, 35000, 35000),
(1, 3, 1, 18000, 18000),
(2, 5, 1, 24000, 24000),
(2, 8, 1, 30000, 30000),
(3, 9, 1, 12000, 12000),
(3, 10, 1, 9000, 9000),
(3, 11, 1, 20000, 20000);

INSERT INTO order_tracking (order_id, status, description, updated_by, current_location, created_at) VALUES
(1, 'Pending', 'Order placed by customer', 2, NULL, '2026-01-10 08:00:00'),
(1, 'Accepted', 'Supplier accepted the order', 5, 'Supplier', '2026-01-10 09:00:00'),
(1, 'Packed', 'Supplier packed the order', 5, 'Supplier', '2026-01-10 11:00:00'),
(1, 'In Transit to Pickup Station', 'Order sent to pickup station', 5, 'Supplier', '2026-01-10 14:00:00'),
(1, 'Arrived at Pickup Station', 'Order arrived at pickup station', 8, 'Makerere Main Gate Station', '2026-01-10 17:00:00'),
(1, 'Ready for Pickup', 'Order is ready for pickup', 8, 'Makerere Main Gate Station', '2026-01-10 17:20:00'),
(2, 'Pending', 'Order placed by customer', 3, NULL, '2026-01-11 10:00:00'),
(2, 'Accepted', 'Supplier accepted the order', 6, 'Supplier', '2026-01-11 11:00:00'),
(2, 'Packed', 'Supplier packed the order', 6, 'Supplier', '2026-01-11 13:00:00'),
(2, 'In Transit to Pickup Station', 'Order sent to pickup station', 6, 'Supplier', '2026-01-11 15:00:00'),
(3, 'Pending', 'Order placed by customer', 4, NULL, '2026-01-12 08:00:00'),
(3, 'Accepted', 'Supplier accepted the order', 7, 'Supplier', '2026-01-12 09:00:00'),
(3, 'Packed', 'Supplier packed the order', 7, 'Supplier', '2026-01-12 10:00:00'),
(3, 'In Transit to Pickup Station', 'Order sent to pickup station', 7, 'Supplier', '2026-01-12 11:00:00'),
(3, 'Arrived at Pickup Station', 'Order arrived at pickup station', 8, 'Mukono Central Station', '2026-01-12 14:00:00'),
(3, 'Ready for Pickup', 'Order is ready for pickup', 8, 'Mukono Central Station', '2026-01-12 14:30:00'),
(3, 'Picked Up', 'Order picked up by customer', 8, 'Mukono Central Station', '2026-01-12 16:00:00'),
(3, 'Completed', 'Customer confirmed order received', 4, 'Mukono Central Station', '2026-01-12 16:05:00');

INSERT INTO notifications (user_id, title, message, status) VALUES
(2, 'Order ready', 'Your order ST-SEED-001 is ready for pickup.', 'unread'),
(3, 'Order in transit', 'Your order ST-SEED-002 is moving to the pickup station.', 'unread');
