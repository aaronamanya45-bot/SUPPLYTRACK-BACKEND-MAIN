const express = require('express');
const trackingController = require('../controllers/trackingController');
const protect = require('../middleware/authMiddleware');
const asyncHandler = require('../middleware/asyncHandler');

const router = express.Router();

router.get('/order/:orderId', protect, asyncHandler(trackingController.getOrderTracking));

module.exports = router;
