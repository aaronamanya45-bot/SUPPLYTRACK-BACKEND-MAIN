const express = require('express');
const profileController = require('../controllers/profileController');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const asyncHandler = require('../middleware/asyncHandler');

const router = express.Router();

router.get('/', protect, asyncHandler(profileController.getProfile));
router.put('/supplier', protect, allowRoles('supplier'), asyncHandler(profileController.updateSupplierProfile));
router.put('/customer', protect, allowRoles('customer'), asyncHandler(profileController.updateCustomerProfile));

module.exports = router;
