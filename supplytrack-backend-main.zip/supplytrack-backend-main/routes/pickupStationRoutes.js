const express = require('express');
const pickupStationController = require('../controllers/pickupStationController');
const protect = require('../middleware/authMiddleware');
const asyncHandler = require('../middleware/asyncHandler');

const router = express.Router();

router.get('/', protect, asyncHandler(pickupStationController.getActivePickupStations));

module.exports = router;
