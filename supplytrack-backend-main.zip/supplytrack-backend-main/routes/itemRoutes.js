const express = require('express');
const itemController = require('../controllers/itemController');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const upload = require('../middleware/uploadMiddleware');
const asyncHandler = require('../middleware/asyncHandler');

const router = express.Router();

router.get('/', asyncHandler(itemController.getItems));
router.get('/supplier/my-items', protect, allowRoles('supplier'), asyncHandler(itemController.getMyItems));
router.get('/:id', asyncHandler(itemController.getItemById));
router.post('/', protect, allowRoles('supplier'), upload.single('image'), asyncHandler(itemController.createItem));
router.put('/:id', protect, allowRoles('supplier'), upload.single('image'), asyncHandler(itemController.updateItem));
router.delete('/:id', protect, allowRoles('supplier'), asyncHandler(itemController.deleteItem));

module.exports = router;
