const express = require('express');
const categoryController = require('../controllers/categoryController');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const asyncHandler = require('../middleware/asyncHandler');

const router = express.Router();

router.get('/', asyncHandler(categoryController.getCategories));
router.post('/', protect, allowRoles('admin'), asyncHandler(categoryController.createCategory));
router.put('/:id', protect, allowRoles('admin'), asyncHandler(categoryController.updateCategory));

module.exports = router;
