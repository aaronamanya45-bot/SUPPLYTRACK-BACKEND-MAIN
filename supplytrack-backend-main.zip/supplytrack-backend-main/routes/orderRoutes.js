const express = require('express');
const orderController = require('../controllers/orderController');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const asyncHandler = require('../middleware/asyncHandler');

const router = express.Router();

router.post('/', protect, allowRoles('customer'), asyncHandler(orderController.placeOrder));
router.get('/my-orders', protect, allowRoles('customer'), asyncHandler(orderController.myOrders));
router.get('/:id', protect, asyncHandler(orderController.getOrderById));
router.put('/:id/cancel', protect, allowRoles('customer'), asyncHandler(orderController.cancelOrder));
router.put('/:id/confirm-received', protect, allowRoles('customer'), asyncHandler(orderController.confirmReceived));

module.exports = router;
