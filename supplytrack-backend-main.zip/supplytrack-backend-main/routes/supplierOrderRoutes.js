const express = require('express');
const supplierOrderController = require('../controllers/supplierOrderController');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const asyncHandler = require('../middleware/asyncHandler');

const router = express.Router();

router.use(protect, allowRoles('supplier'));

router.get('/', asyncHandler(supplierOrderController.getSupplierOrders));
router.put('/:id/accept', asyncHandler(supplierOrderController.acceptOrder));
router.put('/:id/reject', asyncHandler(supplierOrderController.rejectOrder));
router.put('/:id/packed', asyncHandler(supplierOrderController.markPacked));
router.put('/:id/send-to-station', asyncHandler(supplierOrderController.sendToStation));

module.exports = router;
