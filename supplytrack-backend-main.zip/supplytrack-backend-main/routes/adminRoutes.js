const express = require('express');
const adminController = require('../controllers/adminController');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const asyncHandler = require('../middleware/asyncHandler');

const router = express.Router();

router.use(protect, allowRoles('admin'));

router.get('/stats', asyncHandler(adminController.getStats));
router.get('/users', asyncHandler(adminController.getUsers));
router.get('/items', asyncHandler(adminController.getItems));
router.get('/orders', asyncHandler(adminController.getOrders));
router.get('/pickup-stations', asyncHandler(adminController.getPickupStations));
router.post('/pickup-stations', asyncHandler(adminController.createPickupStation));
router.put('/pickup-stations/:id', asyncHandler(adminController.updatePickupStation));
router.put('/users/:id/status', asyncHandler(adminController.updateUserStatus));

module.exports = router;
