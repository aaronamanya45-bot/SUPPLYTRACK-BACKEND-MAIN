const express = require('express');
const cartController = require('../controllers/cartController');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const asyncHandler = require('../middleware/asyncHandler');

const router = express.Router();

router.use(protect, allowRoles('customer'));

router.get('/', asyncHandler(cartController.getCart));
router.post('/items', asyncHandler(cartController.addItem));
router.put('/items/:id', asyncHandler(cartController.updateItem));
router.delete('/items/:id', asyncHandler(cartController.deleteItem));
router.delete('/clear', asyncHandler(cartController.clearCart));

module.exports = router;
