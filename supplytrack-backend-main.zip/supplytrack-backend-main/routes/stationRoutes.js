const express = require('express');
const stationController = require('../controllers/stationController');
const protect = require('../middleware/authMiddleware');
const allowRoles = require('../middleware/roleMiddleware');
const asyncHandler = require('../middleware/asyncHandler');

const router = express.Router();

router.use(protect, allowRoles('station_officer'));

router.get('/', asyncHandler(stationController.getStationOrders));
router.put('/:id/arrived', asyncHandler(stationController.markArrived));
router.put('/:id/ready', asyncHandler(stationController.markReady));
router.put('/:id/picked-up', asyncHandler(stationController.markPickedUp));

module.exports = router;
