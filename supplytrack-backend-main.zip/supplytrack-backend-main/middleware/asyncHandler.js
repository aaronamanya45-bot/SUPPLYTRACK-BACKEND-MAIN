// Express 4 does not automatically catch errors thrown inside async functions.
// This helper forwards those errors to the central error handler in server.js.
const asyncHandler = (controller) => {
  return (req, res, next) => Promise.resolve(controller(req, res, next)).catch(next);
};

module.exports = asyncHandler;
