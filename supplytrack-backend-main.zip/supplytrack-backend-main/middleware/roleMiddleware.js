// Role-based access control keeps each user inside the part of the system they
// are allowed to use. Example: allowRoles('admin', 'supplier').
const allowRoles = (...roles) => {
  return (req, res, next) => {
    if (!req.user || !roles.includes(req.user.role)) {
      return res.status(403).json({ message: 'You do not have permission to access this resource' });
    }

    next();
  };
};

module.exports = allowRoles;
