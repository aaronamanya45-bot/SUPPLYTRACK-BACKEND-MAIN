const pool = require('../config/db');

exports.getProfile = async (req, res) => {
  const [users] = await pool.query(
    'SELECT id, full_name, email, phone, role, status, created_at FROM users WHERE id = ?',
    [req.user.id]
  );

  if (users.length === 0) {
    return res.status(404).json({ message: 'User not found' });
  }

  let supplierProfile = null;
  if (req.user.role === 'supplier') {
    const [profiles] = await pool.query('SELECT * FROM supplier_profiles WHERE user_id = ?', [req.user.id]);
    supplierProfile = profiles[0] || null;
  }

  res.json({ user: users[0], supplierProfile });
};

exports.updateSupplierProfile = async (req, res) => {
  const { business_name, business_description, district, address, phone, status } = req.body;

  if (!business_name) {
    return res.status(400).json({ message: 'Business name is required' });
  }

  const [profiles] = await pool.query('SELECT id FROM supplier_profiles WHERE user_id = ?', [req.user.id]);

  if (profiles.length === 0) {
    const [result] = await pool.query(
      `INSERT INTO supplier_profiles (user_id, business_name, business_description, district, address, phone, status)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [req.user.id, business_name, business_description || null, district || null, address || null, phone || null, status || 'active']
    );
    return res.status(201).json({ message: 'Supplier profile created', profileId: result.insertId });
  }

  await pool.query(
    `UPDATE supplier_profiles
     SET business_name = ?, business_description = ?, district = ?, address = ?, phone = ?, status = ?
     WHERE user_id = ?`,
    [business_name, business_description || null, district || null, address || null, phone || null, status || 'active', req.user.id]
  );

  res.json({ message: 'Supplier profile updated' });
};

exports.updateCustomerProfile = async (req, res) => {
  const { full_name, phone } = req.body;

  if (!full_name) {
    return res.status(400).json({ message: 'Full name is required' });
  }

  await pool.query('UPDATE users SET full_name = ?, phone = ? WHERE id = ?', [full_name, phone || null, req.user.id]);
  res.json({ message: 'Profile updated' });
};
