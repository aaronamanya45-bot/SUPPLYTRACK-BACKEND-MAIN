const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const pool = require('../config/db');

const createToken = (user) => {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role, full_name: user.full_name },
    process.env.JWT_SECRET,
    { expiresIn: '1d' }
  );
};

exports.register = async (req, res) => {
  const { full_name, email, phone, password, role = 'customer' } = req.body;
  const allowedRoles = ['admin', 'customer', 'supplier', 'station_officer'];

  if (!full_name || !email || !password) {
    return res.status(400).json({ message: 'Full name, email, and password are required' });
  }

  if (!allowedRoles.includes(role)) {
    return res.status(400).json({ message: 'Invalid user role' });
  }

  const [existingUsers] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);
  if (existingUsers.length > 0) {
    return res.status(409).json({ message: 'Email is already registered' });
  }

  // Passwords are hashed before saving. Never store plain text passwords.
  const hashedPassword = await bcrypt.hash(password, 10);

  const [result] = await pool.query(
    'INSERT INTO users (full_name, email, phone, password, role) VALUES (?, ?, ?, ?, ?)',
    [full_name, email, phone || null, hashedPassword, role]
  );

  if (role === 'supplier') {
    await pool.query(
      'INSERT INTO supplier_profiles (user_id, business_name, phone) VALUES (?, ?, ?)',
      [result.insertId, `${full_name}'s Supply Business`, phone || null]
    );
  }

  const user = { id: result.insertId, full_name, email, phone, role };
  res.status(201).json({ message: 'Registration successful', token: createToken(user), user });
};

exports.login = async (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  const [users] = await pool.query('SELECT * FROM users WHERE email = ?', [email]);
  const user = users[0];

  if (!user) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }

  if (user.status !== 'active') {
    return res.status(403).json({ message: 'This account is not active' });
  }

  const passwordMatches = await bcrypt.compare(password, user.password);
  if (!passwordMatches) {
    return res.status(401).json({ message: 'Invalid email or password' });
  }

  const safeUser = {
    id: user.id,
    full_name: user.full_name,
    email: user.email,
    phone: user.phone,
    role: user.role,
    status: user.status
  };

  res.json({ message: 'Login successful', token: createToken(safeUser), user: safeUser });
};

exports.me = async (req, res) => {
  const [users] = await pool.query(
    'SELECT id, full_name, email, phone, role, status, created_at FROM users WHERE id = ?',
    [req.user.id]
  );

  if (users.length === 0) {
    return res.status(404).json({ message: 'User not found' });
  }

  res.json(users[0]);
};
