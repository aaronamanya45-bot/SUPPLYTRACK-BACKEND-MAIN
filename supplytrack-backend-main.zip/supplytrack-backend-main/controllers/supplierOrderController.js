const pool = require('../config/db');

const getSupplierProfile = async (userId) => {
  const [profiles] = await pool.query('SELECT * FROM supplier_profiles WHERE user_id = ?', [userId]);
  return profiles[0];
};

const updateOrderStatus = async (orderId, supplierId, status, description, userId) => {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [orders] = await connection.query('SELECT * FROM orders WHERE id = ? AND supplier_id = ?', [orderId, supplierId]);
    if (orders.length === 0) {
      await connection.rollback();
      return false;
    }

    await connection.query('UPDATE orders SET status = ? WHERE id = ?', [status, orderId]);
    await connection.query(
      `INSERT INTO order_tracking (order_id, status, description, updated_by, current_location)
       VALUES (?, ?, ?, ?, ?)`,
      [orderId, status, description, userId, 'Supplier']
    );

    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

exports.getSupplierOrders = async (req, res) => {
  const profile = await getSupplierProfile(req.user.id);
  if (!profile) {
    return res.status(404).json({ message: 'Supplier profile not found' });
  }

  const [orders] = await pool.query(
    `SELECT orders.*, users.full_name AS customer_name, pickup_stations.station_name
     FROM orders
     JOIN users ON users.id = orders.customer_id
     JOIN pickup_stations ON pickup_stations.id = orders.pickup_station_id
     WHERE orders.supplier_id = ?
     ORDER BY orders.created_at DESC`,
    [profile.id]
  );

  res.json(orders);
};

exports.acceptOrder = async (req, res) => {
  const profile = await getSupplierProfile(req.user.id);
  const updated = profile && await updateOrderStatus(req.params.id, profile.id, 'Accepted', 'Supplier accepted the order', req.user.id);
  if (!updated) return res.status(404).json({ message: 'Order not found for this supplier' });
  res.json({ message: 'Order accepted' });
};

exports.rejectOrder = async (req, res) => {
  const profile = await getSupplierProfile(req.user.id);
  const updated = profile && await updateOrderStatus(req.params.id, profile.id, 'Rejected', 'Supplier rejected the order', req.user.id);
  if (!updated) return res.status(404).json({ message: 'Order not found for this supplier' });
  res.json({ message: 'Order rejected' });
};

exports.markPacked = async (req, res) => {
  const profile = await getSupplierProfile(req.user.id);
  const updated = profile && await updateOrderStatus(req.params.id, profile.id, 'Packed', 'Supplier packed the order', req.user.id);
  if (!updated) return res.status(404).json({ message: 'Order not found for this supplier' });
  res.json({ message: 'Order marked as packed' });
};

exports.sendToStation = async (req, res) => {
  const profile = await getSupplierProfile(req.user.id);
  const updated = profile && await updateOrderStatus(
    req.params.id,
    profile.id,
    'In Transit to Pickup Station',
    'Supplier sent order to pickup station',
    req.user.id
  );
  if (!updated) return res.status(404).json({ message: 'Order not found for this supplier' });
  res.json({ message: 'Order sent to pickup station' });
};
