const pool = require('../config/db');

exports.getCategories = async (req, res) => {
  const [categories] = await pool.query('SELECT * FROM item_categories ORDER BY name ASC');
  res.json(categories);
};

exports.createCategory = async (req, res) => {
  const { name, description, status = 'active' } = req.body;

  if (!name) {
    return res.status(400).json({ message: 'Category name is required' });
  }

  const [result] = await pool.query(
    'INSERT INTO item_categories (name, description, status) VALUES (?, ?, ?)',
    [name, description || null, status]
  );

  res.status(201).json({ message: 'Category created', categoryId: result.insertId });
};

exports.updateCategory = async (req, res) => {
  const { name, description, status } = req.body;

  const [existing] = await pool.query('SELECT * FROM item_categories WHERE id = ?', [req.params.id]);
  if (existing.length === 0) {
    return res.status(404).json({ message: 'Category not found' });
  }

  await pool.query(
    'UPDATE item_categories SET name = ?, description = ?, status = ? WHERE id = ?',
    [
      name || existing[0].name,
      description ?? existing[0].description,
      status || existing[0].status,
      req.params.id
    ]
  );

  res.json({ message: 'Category updated' });
};
