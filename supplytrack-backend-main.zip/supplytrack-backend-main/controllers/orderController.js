const pool = require('../config/db');

const createTracking = async (connection, orderId, status, description, userId, location = null) => {
  // Every status change inserts a separate tracking row. Students can query
  // order_tracking later to see the full movement history of an order.
  await connection.query(
    `INSERT INTO order_tracking (order_id, status, description, updated_by, current_location)
     VALUES (?, ?, ?, ?, ?)`,
    [orderId, status, description, userId, location]
  );
};

const canViewOrder = async (order, user) => {
  if (user.role === 'admin' || order.customer_id === user.id) {
    return true;
  }

  if (user.role === 'supplier') {
    const [profiles] = await pool.query('SELECT id FROM supplier_profiles WHERE user_id = ?', [user.id]);
    return profiles.length > 0 && profiles[0].id === order.supplier_id;
  }

  if (user.role === 'station_officer') {
    const [stations] = await pool.query('SELECT id FROM pickup_stations WHERE officer_id = ?', [user.id]);
    return stations.some((station) => station.id === order.pickup_station_id);
  }

  return false;
};

exports.placeOrder = async (req, res) => {
  const { pickup_station_id, customer_notes } = req.body;

  if (!pickup_station_id) {
    return res.status(400).json({ message: 'Pickup station is required' });
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [carts] = await connection.query('SELECT * FROM carts WHERE customer_id = ?', [req.user.id]);
    if (carts.length === 0) {
      await connection.rollback();
      return res.status(400).json({ message: 'Cart is empty' });
    }

    const [cartItems] = await connection.query(
      `SELECT cart_items.*, items.price, items.stock_quantity, items.supplier_id, items.item_name
       FROM cart_items
       JOIN items ON items.id = cart_items.item_id
       WHERE cart_items.cart_id = ? AND items.status = 'active'`,
      [carts[0].id]
    );

    if (cartItems.length === 0) {
      await connection.rollback();
      return res.status(400).json({ message: 'Cart is empty' });
    }

    for (const item of cartItems) {
      if (item.quantity > item.stock_quantity) {
        await connection.rollback();
        return res.status(400).json({ message: `${item.item_name} does not have enough stock` });
      }
    }

    const itemsBySupplier = cartItems.reduce((groups, item) => {
      groups[item.supplier_id] = groups[item.supplier_id] || [];
      groups[item.supplier_id].push(item);
      return groups;
    }, {});

    const createdOrders = [];

    for (const supplierId of Object.keys(itemsBySupplier)) {
      const supplierItems = itemsBySupplier[supplierId];
      const totalAmount = supplierItems.reduce((sum, item) => sum + Number(item.price) * item.quantity, 0);
      const orderNumber = `ST-${Date.now()}-${supplierId}`;

      const [orderResult] = await connection.query(
        `INSERT INTO orders (customer_id, supplier_id, pickup_station_id, order_number, total_amount, customer_notes)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [req.user.id, supplierId, pickup_station_id, orderNumber, totalAmount, customer_notes || null]
      );

      for (const item of supplierItems) {
        await connection.query(
          `INSERT INTO order_items (order_id, item_id, quantity, unit_price, subtotal)
           VALUES (?, ?, ?, ?, ?)`,
          [orderResult.insertId, item.item_id, item.quantity, item.price, Number(item.price) * item.quantity]
        );

        await connection.query(
          'UPDATE items SET stock_quantity = stock_quantity - ? WHERE id = ?',
          [item.quantity, item.item_id]
        );
      }

      await createTracking(connection, orderResult.insertId, 'Pending', 'Order placed by customer', req.user.id);
      createdOrders.push({ id: orderResult.insertId, order_number: orderNumber, total_amount: totalAmount });
    }

    await connection.query('DELETE FROM cart_items WHERE cart_id = ?', [carts[0].id]);
    await connection.commit();

    res.status(201).json({ message: 'Order placed successfully', orders: createdOrders });
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

exports.myOrders = async (req, res) => {
  const [orders] = await pool.query(
    `SELECT orders.*, pickup_stations.station_name, supplier_profiles.business_name AS supplier_name
     FROM orders
     JOIN pickup_stations ON pickup_stations.id = orders.pickup_station_id
     JOIN supplier_profiles ON supplier_profiles.id = orders.supplier_id
     WHERE orders.customer_id = ?
     ORDER BY orders.created_at DESC`,
    [req.user.id]
  );

  res.json(orders);
};

exports.getOrderById = async (req, res) => {
  const [orders] = await pool.query(
    `SELECT orders.*, users.full_name AS customer_name, pickup_stations.station_name,
            supplier_profiles.business_name AS supplier_name
     FROM orders
     JOIN users ON users.id = orders.customer_id
     JOIN pickup_stations ON pickup_stations.id = orders.pickup_station_id
     JOIN supplier_profiles ON supplier_profiles.id = orders.supplier_id
     WHERE orders.id = ?`,
    [req.params.id]
  );

  if (orders.length === 0) {
    return res.status(404).json({ message: 'Order not found' });
  }

  if (!(await canViewOrder(orders[0], req.user))) {
    return res.status(403).json({ message: 'You cannot view this order' });
  }

  const [items] = await pool.query(
    `SELECT order_items.*, items.item_name, items.image
     FROM order_items
     JOIN items ON items.id = order_items.item_id
     WHERE order_items.order_id = ?`,
    [req.params.id]
  );

  res.json({ order: orders[0], items });
};

exports.cancelOrder = async (req, res) => {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [orders] = await connection.query('SELECT * FROM orders WHERE id = ? AND customer_id = ?', [req.params.id, req.user.id]);
    const order = orders[0];

    if (!order) {
      await connection.rollback();
      return res.status(404).json({ message: 'Order not found' });
    }

    if (!['Pending', 'Accepted'].includes(order.status)) {
      await connection.rollback();
      return res.status(400).json({ message: 'Only pending or accepted orders can be cancelled' });
    }

    await connection.query('UPDATE orders SET status = ? WHERE id = ?', ['Cancelled', order.id]);
    await createTracking(connection, order.id, 'Cancelled', 'Order cancelled by customer', req.user.id);
    await connection.commit();

    res.json({ message: 'Order cancelled' });
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

exports.confirmReceived = async (req, res) => {
  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [orders] = await connection.query('SELECT * FROM orders WHERE id = ? AND customer_id = ?', [req.params.id, req.user.id]);
    const order = orders[0];

    if (!order) {
      await connection.rollback();
      return res.status(404).json({ message: 'Order not found' });
    }

    if (!['Picked Up', 'Ready for Pickup'].includes(order.status)) {
      await connection.rollback();
      return res.status(400).json({ message: 'Order is not ready to complete' });
    }

    await connection.query('UPDATE orders SET status = ? WHERE id = ?', ['Completed', order.id]);
    await createTracking(connection, order.id, 'Completed', 'Customer confirmed order received', req.user.id);
    await connection.commit();

    res.json({ message: 'Order completed' });
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};
