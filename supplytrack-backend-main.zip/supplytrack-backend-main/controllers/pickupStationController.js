const pool = require('../config/db');

exports.getActivePickupStations = async (req, res) => {
  const [stations] = await pool.query(
    `SELECT pickup_stations.id, pickup_stations.station_name, pickup_stations.district,
            pickup_stations.location_details, pickup_stations.phone, pickup_stations.status,
            users.full_name AS officer_name
     FROM pickup_stations
     LEFT JOIN users ON users.id = pickup_stations.officer_id
     WHERE pickup_stations.status = 'active'
     ORDER BY pickup_stations.station_name ASC`
  );

  res.json(stations);
};
