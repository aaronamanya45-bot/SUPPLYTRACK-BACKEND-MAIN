const pool = require('../config/db');

exports.getStats = async (req, res) => {
  const [[users]] = await pool.query('SELECT COUNT(*) AS total FROM users');
  const [[items]] = await pool.query('SELECT COUNT(*) AS total FROM items');
  const [[orders]] = await pool.query('SELECT COUNT(*) AS total FROM orders');
  const [[stations]] = await pool.query('SELECT COUNT(*) AS total FROM pickup_stations');
  const [[sales]] = await pool.query('SELECT COALESCE(SUM(total_amount), 0) AS total FROM orders WHERE status <> "Cancelled"');

  res.json({
    users: users.total,
    items: items.total,
    orders: orders.total,
    pickupStations: stations.total,
    totalSales: sales.total
  });
};

exports.getUsers = async (req, res) => {
  const [users] = await pool.query(
    'SELECT id, full_name, email, phone, role, status, created_at FROM users ORDER BY created_at DESC'
  );
  res.json(users);
};

exports.getItems = async (req, res) => {
  const [items] = await pool.query(
    `SELECT items.*, supplier_profiles.business_name AS supplier_name, item_categories.name AS category_name
     FROM items
     JOIN supplier_profiles ON supplier_profiles.id = items.supplier_id
     LEFT JOIN item_categories ON item_categories.id = items.category_id
     ORDER BY items.created_at DESC`
  );
  res.json(items);
};

exports.getOrders = async (req, res) => {
  const [orders] = await pool.query(
    `SELECT orders.*, users.full_name AS customer_name, supplier_profiles.business_name AS supplier_name,
            pickup_stations.station_name
     FROM orders
     JOIN users ON users.id = orders.customer_id
     JOIN supplier_profiles ON supplier_profiles.id = orders.supplier_id
     JOIN pickup_stations ON pickup_stations.id = orders.pickup_station_id
     ORDER BY orders.created_at DESC`
  );
  res.json(orders);
};

exports.getPickupStations = async (req, res) => {
  const [stations] = await pool.query(
    `SELECT pickup_stations.*, users.full_name AS officer_name
     FROM pickup_stations
     LEFT JOIN users ON users.id = pickup_stations.officer_id
     ORDER BY pickup_stations.created_at DESC`
  );
  res.json(stations);
};

exports.createPickupStation = async (req, res) => {
  const { station_name, district, location_details, officer_id, phone, status = 'active' } = req.body;

  if (!station_name || !district) {
    return res.status(400).json({ message: 'Station name and district are required' });
  }

  const [result] = await pool.query(
    `INSERT INTO pickup_stations (station_name, district, location_details, officer_id, phone, status)
     VALUES (?, ?, ?, ?, ?, ?)`,
    [station_name, district, location_details || null, officer_id || null, phone || null, status]
  );

  res.status(201).json({ message: 'Pickup station created', stationId: result.insertId });
};

exports.updatePickupStation = async (req, res) => {
  const { station_name, district, location_details, officer_id, phone, status } = req.body;
  const [stations] = await pool.query('SELECT * FROM pickup_stations WHERE id = ?', [req.params.id]);

  if (stations.length === 0) {
    return res.status(404).json({ message: 'Pickup station not found' });
  }

  const station = stations[0];
  await pool.query(
    `UPDATE pickup_stations
     SET station_name = ?, district = ?, location_details = ?, officer_id = ?, phone = ?, status = ?
     WHERE id = ?`,
    [
      station_name || station.station_name,
      district || station.district,
      location_details ?? station.location_details,
      officer_id || station.officer_id,
      phone ?? station.phone,
      status || station.status,
      req.params.id
    ]
  );

  res.json({ message: 'Pickup station updated' });
};

exports.updateUserStatus = async (req, res) => {
  const { status } = req.body;

  if (!['active', 'inactive'].includes(status)) {
    return res.status(400).json({ message: 'Status must be active or inactive' });
  }

  const [result] = await pool.query('UPDATE users SET status = ? WHERE id = ?', [status, req.params.id]);
  if (result.affectedRows === 0) {
    return res.status(404).json({ message: 'User not found' });
  }

  res.json({ message: 'User status updated' });
};
