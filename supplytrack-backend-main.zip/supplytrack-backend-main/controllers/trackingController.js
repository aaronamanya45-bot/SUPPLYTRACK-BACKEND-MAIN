const pool = require('../config/db');

const canViewTracking = async (order, user) => {
  if (user.role === 'admin' || order.customer_id === user.id) {
    return true;
  }

  if (user.role === 'supplier') {
    const [profiles] = await pool.query('SELECT id FROM supplier_profiles WHERE user_id = ?', [user.id]);
    return profiles.length > 0 && profiles[0].id === order.supplier_id;
  }

  if (user.role === 'station_officer') {
    const [stations] = await pool.query('SELECT id FROM pickup_stations WHERE officer_id = ?', [user.id]);
    return stations.some((station) => station.id === order.pickup_station_id);
  }

  return false;
};

exports.getOrderTracking = async (req, res) => {
  const [orders] = await pool.query('SELECT * FROM orders WHERE id = ?', [req.params.orderId]);
  const order = orders[0];

  if (!order) {
    return res.status(404).json({ message: 'Order not found' });
  }

  if (!(await canViewTracking(order, req.user))) {
    return res.status(403).json({ message: 'You cannot view tracking for this order' });
  }

  const [tracking] = await pool.query(
    `SELECT order_tracking.*, users.full_name AS updated_by_name
     FROM order_tracking
     LEFT JOIN users ON users.id = order_tracking.updated_by
     WHERE order_tracking.order_id = ?
     ORDER BY order_tracking.created_at ASC`,
    [req.params.orderId]
  );

  res.json(tracking);
};
