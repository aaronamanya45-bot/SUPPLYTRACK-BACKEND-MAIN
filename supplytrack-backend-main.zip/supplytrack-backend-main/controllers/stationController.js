const pool = require('../config/db');

const getOfficerStations = async (officerId) => {
  const [stations] = await pool.query('SELECT * FROM pickup_stations WHERE officer_id = ?', [officerId]);
  return stations;
};

const updateStationOrder = async (orderId, officerId, status, description, note) => {
  const stations = await getOfficerStations(officerId);
  const stationIds = stations.map((station) => station.id);

  if (stationIds.length === 0) {
    return false;
  }

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();
    const [orders] = await connection.query(
      `SELECT orders.*, pickup_stations.station_name
       FROM orders
       JOIN pickup_stations ON pickup_stations.id = orders.pickup_station_id
       WHERE orders.id = ? AND orders.pickup_station_id IN (?)`,
      [orderId, stationIds]
    );

    if (orders.length === 0) {
      await connection.rollback();
      return false;
    }

    await connection.query('UPDATE orders SET status = ? WHERE id = ?', [status, orderId]);
    await connection.query(
      `INSERT INTO order_tracking (order_id, status, description, updated_by, current_location)
       VALUES (?, ?, ?, ?, ?)`,
      [orderId, status, note || description, officerId, orders[0].station_name]
    );

    await connection.commit();
    return true;
  } catch (error) {
    await connection.rollback();
    throw error;
  } finally {
    connection.release();
  }
};

exports.getStationOrders = async (req, res) => {
  const stations = await getOfficerStations(req.user.id);
  const stationIds = stations.map((station) => station.id);

  if (stationIds.length === 0) {
    return res.json([]);
  }

  const [orders] = await pool.query(
    `SELECT orders.*, users.full_name AS customer_name, pickup_stations.station_name,
            supplier_profiles.business_name AS supplier_name
     FROM orders
     JOIN users ON users.id = orders.customer_id
     JOIN pickup_stations ON pickup_stations.id = orders.pickup_station_id
     JOIN supplier_profiles ON supplier_profiles.id = orders.supplier_id
     WHERE orders.pickup_station_id IN (?)
     ORDER BY orders.created_at DESC`,
    [stationIds]
  );

  res.json(orders);
};

exports.markArrived = async (req, res) => {
  const updated = await updateStationOrder(
    req.params.id,
    req.user.id,
    'Arrived at Pickup Station',
    'Order arrived at pickup station',
    req.body.note
  );
  if (!updated) return res.status(404).json({ message: 'Order not found for your station' });
  res.json({ message: 'Order marked as arrived' });
};

exports.markReady = async (req, res) => {
  const updated = await updateStationOrder(req.params.id, req.user.id, 'Ready for Pickup', 'Order is ready for pickup', req.body.note);
  if (!updated) return res.status(404).json({ message: 'Order not found for your station' });
  res.json({ message: 'Order marked ready for pickup' });
};

exports.markPickedUp = async (req, res) => {
  const updated = await updateStationOrder(req.params.id, req.user.id, 'Picked Up', 'Order picked up by customer', req.body.note);
  if (!updated) return res.status(404).json({ message: 'Order not found for your station' });
  res.json({ message: 'Order marked as picked up' });
};
