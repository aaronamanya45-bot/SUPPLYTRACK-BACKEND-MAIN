const pool = require('../config/db');

const getOrCreateCart = async (customerId) => {
  const [carts] = await pool.query('SELECT * FROM carts WHERE customer_id = ?', [customerId]);
  if (carts.length > 0) {
    return carts[0];
  }

  const [result] = await pool.query('INSERT INTO carts (customer_id) VALUES (?)', [customerId]);
  return { id: result.insertId, customer_id: customerId };
};

exports.getCart = async (req, res) => {
  const cart = await getOrCreateCart(req.user.id);
  const [items] = await pool.query(
    `SELECT cart_items.*, items.item_name, items.price, items.stock_quantity, items.image,
            supplier_profiles.business_name AS supplier_name
     FROM cart_items
     JOIN items ON items.id = cart_items.item_id
     JOIN supplier_profiles ON supplier_profiles.id = items.supplier_id
     WHERE cart_items.cart_id = ?`,
    [cart.id]
  );

  res.json({ cart, items });
};

exports.addItem = async (req, res) => {
  const { item_id, quantity = 1 } = req.body;
  if (!item_id) {
    return res.status(400).json({ message: 'Item is required' });
  }

  const cart = await getOrCreateCart(req.user.id);
  const [existing] = await pool.query('SELECT * FROM cart_items WHERE cart_id = ? AND item_id = ?', [cart.id, item_id]);

  if (existing.length > 0) {
    await pool.query('UPDATE cart_items SET quantity = quantity + ? WHERE id = ?', [quantity, existing[0].id]);
    return res.json({ message: 'Cart quantity updated' });
  }

  await pool.query('INSERT INTO cart_items (cart_id, item_id, quantity) VALUES (?, ?, ?)', [cart.id, item_id, quantity]);
  res.status(201).json({ message: 'Item added to cart' });
};

exports.updateItem = async (req, res) => {
  const { quantity } = req.body;
  if (!quantity || quantity < 1) {
    return res.status(400).json({ message: 'Quantity must be at least 1' });
  }

  const cart = await getOrCreateCart(req.user.id);
  const [result] = await pool.query(
    'UPDATE cart_items SET quantity = ? WHERE id = ? AND cart_id = ?',
    [quantity, req.params.id, cart.id]
  );

  if (result.affectedRows === 0) {
    return res.status(404).json({ message: 'Cart item not found' });
  }

  res.json({ message: 'Cart item updated' });
};

exports.deleteItem = async (req, res) => {
  const cart = await getOrCreateCart(req.user.id);
  const [result] = await pool.query('DELETE FROM cart_items WHERE id = ? AND cart_id = ?', [req.params.id, cart.id]);

  if (result.affectedRows === 0) {
    return res.status(404).json({ message: 'Cart item not found' });
  }

  res.json({ message: 'Cart item removed' });
};

exports.clearCart = async (req, res) => {
  const cart = await getOrCreateCart(req.user.id);
  await pool.query('DELETE FROM cart_items WHERE cart_id = ?', [cart.id]);
  res.json({ message: 'Cart cleared' });
};
