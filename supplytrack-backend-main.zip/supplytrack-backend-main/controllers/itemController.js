const pool = require('../config/db');

const getSupplierProfile = async (userId) => {
  const [profiles] = await pool.query('SELECT * FROM supplier_profiles WHERE user_id = ?', [userId]);
  return profiles[0];
};

exports.getItems = async (req, res) => {
  const { search, category, supplier, minPrice, maxPrice, available } = req.query;
  const conditions = ['items.status = ?'];
  const values = ['active'];

  if (search) {
    conditions.push('(items.item_name LIKE ? OR items.description LIKE ?)');
    values.push(`%${search}%`, `%${search}%`);
  }

  if (category) {
    conditions.push('item_categories.name LIKE ?');
    values.push(`%${category}%`);
  }

  if (supplier) {
    conditions.push('supplier_profiles.business_name LIKE ?');
    values.push(`%${supplier}%`);
  }

  if (minPrice) {
    conditions.push('items.price >= ?');
    values.push(Number(minPrice));
  }

  if (maxPrice) {
    conditions.push('items.price <= ?');
    values.push(Number(maxPrice));
  }

  if (available === 'true') {
    conditions.push('items.stock_quantity > 0');
  }

  const [items] = await pool.query(
    `SELECT items.*, item_categories.name AS category_name, supplier_profiles.business_name AS supplier_name
     FROM items
     JOIN supplier_profiles ON supplier_profiles.id = items.supplier_id
     LEFT JOIN item_categories ON item_categories.id = items.category_id
     WHERE ${conditions.join(' AND ')}
     ORDER BY items.created_at DESC`,
    values
  );

  res.json(items);
};

exports.getItemById = async (req, res) => {
  const [items] = await pool.query(
    `SELECT items.*, item_categories.name AS category_name, supplier_profiles.business_name AS supplier_name
     FROM items
     JOIN supplier_profiles ON supplier_profiles.id = items.supplier_id
     LEFT JOIN item_categories ON item_categories.id = items.category_id
     WHERE items.id = ?`,
    [req.params.id]
  );

  if (items.length === 0) {
    return res.status(404).json({ message: 'Item not found' });
  }

  res.json(items[0]);
};

exports.getMyItems = async (req, res) => {
  const profile = await getSupplierProfile(req.user.id);
  if (!profile) {
    return res.status(404).json({ message: 'Supplier profile not found' });
  }

  const [items] = await pool.query(
    `SELECT items.*, item_categories.name AS category_name
     FROM items
     LEFT JOIN item_categories ON item_categories.id = items.category_id
     WHERE items.supplier_id = ?
     ORDER BY items.created_at DESC`,
    [profile.id]
  );

  res.json(items);
};

exports.createItem = async (req, res) => {
  const { category_id, item_name, description, price, stock_quantity, unit } = req.body;
  const profile = await getSupplierProfile(req.user.id);

  if (!profile) {
    return res.status(404).json({ message: 'Supplier profile not found' });
  }

  if (!item_name || !price || stock_quantity === undefined) {
    return res.status(400).json({ message: 'Item name, price, and stock quantity are required' });
  }

  const image = req.file ? `/uploads/item-images/${req.file.filename}` : null;

  const [result] = await pool.query(
    `INSERT INTO items (supplier_id, category_id, item_name, description, price, stock_quantity, unit, image)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
    [profile.id, category_id || null, item_name, description || null, price, stock_quantity, unit || 'piece', image]
  );

  res.status(201).json({ message: 'Item created', itemId: result.insertId, image });
};

exports.updateItem = async (req, res) => {
  const { category_id, item_name, description, price, stock_quantity, unit, status } = req.body;
  const profile = await getSupplierProfile(req.user.id);

  if (!profile) {
    return res.status(404).json({ message: 'Supplier profile not found' });
  }

  const [items] = await pool.query('SELECT * FROM items WHERE id = ? AND supplier_id = ?', [req.params.id, profile.id]);
  if (items.length === 0) {
    return res.status(404).json({ message: 'Item not found for this supplier' });
  }

  const current = items[0];
  const image = req.file ? `/uploads/item-images/${req.file.filename}` : current.image;

  await pool.query(
    `UPDATE items
     SET category_id = ?, item_name = ?, description = ?, price = ?, stock_quantity = ?, unit = ?, image = ?, status = ?
     WHERE id = ? AND supplier_id = ?`,
    [
      category_id || current.category_id,
      item_name || current.item_name,
      description ?? current.description,
      price ?? current.price,
      stock_quantity ?? current.stock_quantity,
      unit || current.unit,
      image,
      status || current.status,
      req.params.id,
      profile.id
    ]
  );

  res.json({ message: 'Item updated' });
};

exports.deleteItem = async (req, res) => {
  const profile = await getSupplierProfile(req.user.id);
  if (!profile) {
    return res.status(404).json({ message: 'Supplier profile not found' });
  }

  const [result] = await pool.query(
    'UPDATE items SET status = ? WHERE id = ? AND supplier_id = ?',
    ['inactive', req.params.id, profile.id]
  );

  if (result.affectedRows === 0) {
    return res.status(404).json({ message: 'Item not found for this supplier' });
  }

  res.json({ message: 'Item deactivated' });
};
